<?php
// path: custom/Espo/Modules/SRNCashFlow/Entities/SRNFinancialMovement.php
namespace Espo\Modules\SRNCashFlow\Entities;
use Espo\Core\ORM\Entity;

class SRNFinancialMovement extends Entity {}