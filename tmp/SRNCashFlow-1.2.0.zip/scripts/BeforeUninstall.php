<?php
class BeforeUninstall
{
    public function run($container, array $params = [])
    {
        return true;
    }
}