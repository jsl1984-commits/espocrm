<?php
// path: custom/Espo/Modules/SRNCashFlow/Entities/SRNEmployee.php
namespace Espo\Modules\SRNCashFlow\Entities;
use Espo\Core\ORM\Entity;

class SRNEmployee extends Entity {}