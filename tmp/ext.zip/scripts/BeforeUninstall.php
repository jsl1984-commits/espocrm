<?php
class BeforeUninstall
{
    public function run($GLOBALS['container'])
    {
        return true;
    }
}