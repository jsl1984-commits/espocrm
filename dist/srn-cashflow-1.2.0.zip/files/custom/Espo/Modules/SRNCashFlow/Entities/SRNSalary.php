<?php
// path: custom/Espo/Modules/SRNCashFlow/Entities/SRNSalary.php
namespace Espo\Modules\SRNCashFlow\Entities;
use Espo\Core\ORM\Entity;

class SRNSalary extends Entity {}